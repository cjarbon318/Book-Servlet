package com.hw4.springbooks;

import com.hw4.springbooks.model.Book;
import com.hw4.springbooks.model.BookDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/SpringBooks")
public class BookController {

    @Autowired
    private BookDAO bookDAO;

    @GetMapping("/bookForm")
    public String showBookForm(Model model) {
        
        return "bookForm";
    }

    @PostMapping("/addBooks")
    public String addBooks(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        System.out.println("Adding Books...");

        String[] isbns = request.getParameterValues("isbn");
        String[] titles = request.getParameterValues("title");
        String[] authors = request.getParameterValues("author");
        String[] prices = request.getParameterValues("price");

        if (isbns == null || titles == null || authors == null || prices == null ||
                isbns.length == 0 || titles.length == 0 || authors.length == 0 || prices.length == 0) {
            redirectAttributes.addFlashAttribute("errorMessage", "All fields are required for at least one book.");
            return "redirect:/SpringBooks/bookForm"; 
        }

        List<Book> books = new ArrayList<>();

        try {
            for (int i = 0; i < isbns.length; i++) {
                String isbn = isbns[i];
                String title = titles[i];
                String author = authors[i];
                String priceStr = prices[i];

                if (isbn == null || title == null || author == null || priceStr == null ||
                        isbn.trim().isEmpty() || title.trim().isEmpty() || author.trim().isEmpty() || priceStr.trim().isEmpty()) {
                    redirectAttributes.addFlashAttribute("errorMessage", "All fields are required for book: " + (i + 1));
                    return "redirect:/SpringBooks/bookForm";
                }

                float price = Float.parseFloat(priceStr.trim());
                Book book = new Book(isbn.trim(), title.trim(), author.trim(), price);
                books.add(book);
            }

            bookDAO.addBooks(books);

            System.out.println("Books added successfully!");
            redirectAttributes.addFlashAttribute("confirmationMessage", "Books added successfully!");
            return "redirect:/SpringBooks/bookList";
        } catch (NumberFormatException e) {
            System.out.println("Failed to add books:");
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid price format for one of the books.");
            return "redirect:/SpringBooks/bookForm";
        }
    }

    @GetMapping("/bookList")
    public String showBookList(Model model) {
        List<Book> books = bookDAO.getAllBooks();
        model.addAttribute("books", books);
        return "bookList";
    }
}
